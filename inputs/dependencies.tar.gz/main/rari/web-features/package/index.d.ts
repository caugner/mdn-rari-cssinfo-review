declare const browsers: import("./types.quicktype").Browsers, features: {
    [key: string]: import("./types").FeatureData | import("./types").FeatureMovedData | import("./types").FeatureSplitData;
}, groups: {
    [key: string]: import("./types.quicktype").GroupData;
}, snapshots: {
    [key: string]: import("./types.quicktype").SnapshotData;
};
export { browsers, features, groups, snapshots };
